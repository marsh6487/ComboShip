# Saria reward receipt source recovery

Baseline: `525b3160660225a06700470fb39d9d4948834414`. Implementation: `4068936e80a322909b6f679e2850804040cb7842`. Tree: `743dd6dd11f804738277933ea6b2f9de9304af46`.

Fetch the baseline from marsh6487/ComboShip, then either apply `source.patch` to that baseline or fetch the included `source.bundle` branch `fix/saria-song-receipt-crash-20261021`. The `source/` directory contains every complete changed file; their SHA-256 values are in `manifest.json`. This is a source candidate, with no changed or bundled game assets. Rebuild the executable before gameplay testing.

Run `python -B tests/custom_messages/run_decoder_tests.py`, `python -B scripts/diagnostics/run_forest_actor_tests.py` and `python -B scripts/diagnostics/run_mm_item_receipt_tests.py --catalog-only` with external nlohmann-json/spdlog headers available. The negative-control log uses the original Saria source from the exact baseline, inserted in memory by the same runner, and is expected to fail at native decoder index 200. Green uses the corrected source. Verification does not render the game or exercise input-driven closure.

The log/dump provided by cor are unchanged and intentionally absent from this source packet. Their identities and the Windows module evidence are recorded in the POC document.

Independent restoration verified both patch and bundle against the exact tree, without Git object alternates.
