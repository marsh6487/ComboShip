# Restore the reviewed morning source

Implementation: 38c9e66648ec3704d4c21633421301052af5f27c
Tree: 9e748ecac5cc10c255f08ec20066233db2210b3a
Baseline: 66bde021ccd651a3728db2338251961b1a44c9f7

The implementation is published in the cumulative candidate. This package also preserves the original local commit graph independently of later API commit metadata. Native game archives are separate user inputs; their identities are in checkpoint.json.

## Bundle route

Clone marsh6487/ComboShip normally, or use the verified shallow recovery route:

```sh
git clone --bare --filter=blob:none --depth=3 --single-branch --branch checkpoint/morning-entrances-20261021 https://github.com/marsh6487/ComboShip.git recovered.git
git -C recovered.git bundle verify /absolute/path/to/source.bundle
git -C recovered.git fetch /absolute/path/to/source.bundle refs/heads/integration/morning-roundup-20261021:refs/heads/restored-morning
git -C recovered.git worktree add ../restored-source restored-morning
git -C ../restored-source rev-parse HEAD HEAD^{tree}
```

The outputs must equal the implementation commit/tree above. A normal full clone is also supported. The bundle prerequisites are pinned in checkpoint.json.

## Patch route

Check out the exact baseline in a separate worktree and run `git apply --binary source.patch`. This reconstructs the reviewed files without requiring the local commit graph. Do not apply it on top of the already-integrated candidate.

## Native asset reconstruction

Run `python3 -B scripts/assets/prepare_native_forest.py` in the restored source. It must reconstruct the pinned canonical ZIP from tracked parts and prepare85 resources/12 authored textures for both port trees. No cached ZIP or external whole-forest pack is needed.

## Verification and boundaries

Evidence includes complete final entrance, conditional Fairy, native-mesh Woodfall, dedicated vertical draw RED/GREEN, both-host solo routes, core/forest audit summaries, independent review, native units and fresh remote recovery. Initial environment/setup failures and expected RED controls are labeled in their logs. Historical overlay combinations, configured gameplay and full platform linking remain separate checks.

The native-base market adapter is preserved as tested evidence. To replay elsewhere, adjust ROOT and MM_BASE in run_native_base_entry.py to the restored repository and separately supplied pinned native archive. Its scope deliberately excludes historical overlay mode and full application archive mounting.
