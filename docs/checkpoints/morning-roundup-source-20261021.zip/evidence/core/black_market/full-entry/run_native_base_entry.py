#!/usr/bin/env python3
"""Run existing market native route fixtures with the available real MM donor.

This is a separate evidence adapter, not the runner's historical full-input mode.
No tracked source is modified. Only the temporary fixture main and readiness
field name change; cycle/failure assertions and production extraction stay intact.
"""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
from types import SimpleNamespace
from unittest.mock import patch
import zipfile

ROOT = Path('/workspace/scratch/052a9541c216/comboship-morning')
OUTPUT = Path(__file__).resolve().parent
MM_BASE = Path('/workspace/scratch/4640d9491155/inputs/mm.o2r')
sys.path.insert(0, str(ROOT / 'tests/black_market'))
import run_resource_entry_tests as runner


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)


def index_tree():
    """Calculate the staged Git tree ID without writing objects or the index."""
    tree = {}
    for row in git('ls-files', '--stage', '-z').split(b'\0'):
        if not row:
            continue
        metadata, path = row.split(b'\t', 1)
        mode, object_id, stage = metadata.split()
        assert stage == b'0', 'unmerged index is outside this audit'
        current = tree
        pieces = path.split(b'/')
        for piece in pieces[:-1]:
            current = current.setdefault(piece, {})
        current[pieces[-1]] = (mode.lstrip(b'0'), object_id)

    def calculate(node):
        entries = []
        for name, entry in node.items():
            if isinstance(entry, dict):
                mode, object_id = b'40000', calculate(entry)
            else:
                mode, object_id = entry
            entries.append((name + (b'/' if mode == b'40000' else b''),
                            mode + b' ' + name + b'\0' + bytes.fromhex(object_id.decode())))
        payload = b''.join(value for _, value in sorted(entries))
        return hashlib.sha1(b'tree ' + str(len(payload)).encode() + b'\0' + payload).hexdigest().encode()
    return calculate(tree).decode()


def source_snapshot(label):
    delta = git('diff', '--binary', 'HEAD')
    (OUTPUT / (label + '-worktree.patch')).write_bytes(delta)
    return {'head': git('rev-parse', 'HEAD').decode().strip(),
            'head_tree': git('rev-parse', 'HEAD^{tree}').decode().strip(),
            'calculated_index_tree': index_tree(),
            'worktree_delta_sha256': hashlib.sha256(delta).hexdigest()}


def main():
    OUTPUT.mkdir(parents=True, exist_ok=True)
    before = source_snapshot('before')
    args = SimpleNamespace(bundled_only=True, mm_base=None, authored_forest=None, market_pack=None)
    input_path, receipt = runner.build_input(args, OUTPUT)
    data = json.loads(input_path.read_text())
    manifest = json.loads((ROOT / 'tools/native_forest/manifest.json').read_text())
    with zipfile.ZipFile(MM_BASE) as archive:
        names = archive.namelist()
        assert len(names) == len(set(names)) and archive.testzip() is None
        chosen = [name for name in names if name.startswith('objects/object_bg/')
                  or name in manifest['external_resources']
                  or name == runner.native_forest.NATIVE + '_room_00']
        resources = {name: archive.read(name) for name in chosen}
    missing = sorted(set(manifest['external_resources']) - set(resources))
    assert not missing, missing
    base_index = runner.write_resources(OUTPUT / 'actual-mm-base', resources)
    data['base_files'] = base_index
    data['base_hashes'] = [{'hash': runner.native_forest.crc64(name), 'path': name}
                           for name in base_index]
    data['scenarios']['mm_native']['files'].update(base_index)
    # Retain the historical-mode truth value. The temporary fixture explicitly
    # asks whether this separate adapter has its actual native base available.
    assert data['full_real_inputs'] is False
    data['native_base_present'] = True
    data['adapter_scope'] = 'current native MM base plus committed scene/room/collision resources; no historical overlays'
    input_path.write_text(json.dumps(data, indent=2) + '\n')

    fixture_path = ROOT / 'tests/black_market/resource_entry_test.inc'
    original_read_text = Path.read_text
    fixture = original_read_text(fixture_path)
    fixture = fixture.replace('"full_real_inputs"', '"native_base_present"')
    fixture = fixture[:fixture.index('int main(int argc, char** argv) {')] + '''
int main(int argc, char** argv) {
    setvbuf(stdout, nullptr, _IONBF, 0);
    assert(argc == 2); ReadEntryInput(argv[1]);
    assert(inputResources.at("native_base_present").get<bool>());
    assert(!inputResources.at("full_real_inputs").get<bool>());
#ifdef OOT_RESOURCE_ENTRY_TEST
    for (bool stock : {false, true}) TestResourceEntryCycle("oot_native", "oot", stock);
    TestResourceFailures("oot_native", "oot");
#else
    for (const char* forest : {"combined", "mm"})
        for (bool stock : {false, true}) TestResourceEntryCycle("mm_native", forest, stock);
    TestResourceFailures("mm_native", "combined");
    TestResourceFailures("mm_native", "mm");
#endif
    puts("BOUNDARY: actual available native MM base/keeper and committed resources; historical overlays absent; no application resource manager or game execution");
}
'''
    (OUTPUT / 'native-base-resource-entry-test.inc').write_text(fixture)

    def adapted_read_text(path, *args, **kwargs):
        return fixture if path == fixture_path else original_read_text(path, *args, **kwargs)

    includes = [Path('/workspace/scratch/632353d61c30/test-dependencies/nlohmann_json/include'),
                Path('/workspace/scratch/632353d61c30/test-dependencies/spdlog/include')]
    with patch.object(Path, 'read_text', adapted_read_text):
        executables = [runner.build_and_run(host, OUTPUT, input_path, includes) for host in ('mm', 'oot')]

    after = source_snapshot('after')
    receipt.update({'mode': 'available-native-base-and-committed-resources',
                    'full_real_inputs': False,
                    'native_base_present': True,
                    'base_sha256': digest(MM_BASE), 'base_path': str(MM_BASE),
                    'base_resources_consumed': len(base_index),
                    'keeper_resources_consumed': sum(name.startswith('objects/object_bg/') for name in base_index),
                    'external_resource_status': 'actual available mm.o2r owner; every required forest path present',
                    'historical_full_cli_blocker': {'expected_mm_sha256': manifest['inputs']['native_mm']['sha256'],
                        'available_mm_sha256': digest(MM_BASE),
                        'missing_inputs': ['historical authored POC19 forest archive', 'historical POC14 market archive']},
                    'source_snapshot_before': before, 'source_snapshot_after': after,
                    'executables': executables,
                    'adapter_sha256': digest(Path(__file__)),
                    'adapted_fixture_sha256': digest(OUTPUT / 'native-base-resource-entry-test.inc'),
                    'base_resource_sha256': {name: hashlib.sha256(value).hexdigest() for name, value in resources.items()},
                    'result': 'PASS available native-base/keeper production-controller routes; historical overlay configurations and configured gameplay untested'})
    unchanged = {}
    for name, expected in receipt['production_unit_sha256'].items():
        unchanged[name] = digest(ROOT / name) == expected
    receipt['production_units_unchanged_during_run'] = unchanged
    (OUTPUT / 'native-base-entry-receipt.json').write_text(json.dumps(receipt, indent=2, sort_keys=True) + '\n')
    assert all(unchanged.values()), 'production source changed during the run; inspect receipt'
    print('PASS available native base/keeper entry receipt:', OUTPUT / 'native-base-entry-receipt.json', flush=True)


if __name__ == '__main__':
    main()
