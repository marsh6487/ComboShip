Baseline: marsh6487/ComboShip 525b3160660225a06700470fb39d9d4948834414
Restore a fresh checkout of that revision and run: git apply CHANGES.patch
Stage the five paths in RESTORE.json; git write-tree must equal its implementation_tree.
Complete changed files are under source/. Immutable market bundle stays in the baseline.
Run: python3 -B tests/black_market/run_collision_pool_tests.py
The prior baseline is expected to fail with --source-ref 525b316.
This candidate is not in-game/master acceptance.
