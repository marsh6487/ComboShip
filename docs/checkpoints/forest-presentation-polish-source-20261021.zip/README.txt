ComboShip Lost Woods presentation source candidate — 2026-10-21

Source commit (local): 90ec6ebe83a02211ec1af9027f546a5d29d6f21a
Source commit (GitHub): 7233eeb59ae6acd3a56b5c94594159579aba035d
Exact source tree: 0255cb1de3f53dcc169846d063f092db09653ee0
Parent: 724e0476b1dd2555f40faf7cc01b8d1cf0329ecd

This package contains the 19 changed source files, exact Git patch, delta Git bundle, source hashes and decisive verification evidence. It does not contain a game executable or copyrighted ROM assets. The required unchanged source resources remain in the existing public repository at the pinned parent. Source publication was explicitly approved by cor. The exact GitHub implementation commit is 7233eeb59ae6acd3a56b5c94594159579aba035d. Executable builds remain held.

Restore into a fresh clone of https://github.com/marsh6487/ComboShip checked out at the parent above. Run: python restore.py /absolute/path/to/clone
The helper requires the exact baseline and clean tracked files, applies the patch to the index, and verifies the exact candidate tree and every changed source hash. Alternatively fetch candidate.bundle into the baseline clone; its HEAD is the exact local source commit above.

See source/docs/poc/forest-presentation-polish-20261021.md for scope, preserved invariants and the small in-game acceptance pass. All six native resource ZIP parts are unchanged. The four derived cosmetic resources are reproducible from the source recipe and pinned receipt.

Status: implemented and source/native verified; configured gameplay rendering, Alt Assets, transitions and user acceptance remain pending. No running master is promoted. Other pending Fairy/Mirror ritual source branches remain separate integration work.
