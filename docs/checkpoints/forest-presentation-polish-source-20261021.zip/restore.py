from pathlib import Path
import hashlib,json,subprocess,sys
package=Path(__file__).resolve().parent
checkout=Path(sys.argv[1]).resolve()
meta=json.loads((package/'checkpoint.json').read_text())
patch=package/'source.patch'
assert hashlib.sha256(patch.read_bytes()).hexdigest()==meta['patch_sha256']
def git(*args): return subprocess.check_output(['git','-C',str(checkout),*args],text=True).strip()
assert git('write-tree')==meta['baseline_tree'], 'Checkout/index must match the pinned baseline tree'
subprocess.run(['git','-C',str(checkout),'diff','--exit-code'],check=True)
subprocess.run(['git','-C',str(checkout),'apply','--check','--index',str(patch)],check=True)
subprocess.run(['git','-C',str(checkout),'apply','--index',str(patch)],check=True)
assert git('write-tree')==meta['candidate_tree']
for name,digest in meta['source_files'].items():
    assert hashlib.sha256((checkout/name).read_bytes()).hexdigest()==digest,name
print('PASS independently restored candidate tree '+meta['candidate_tree'])
