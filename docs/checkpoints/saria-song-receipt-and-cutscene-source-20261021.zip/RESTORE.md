# Saria reward and cutscene dialogue source recovery

Baseline `590376a6a53b612aa84c6b1f6203571e064e7d23` already includes the Black Market collision correction. Implementation `cd34772a4ed8533cff14a4d24cd7bb9e171311ed`, exact tree `6366f247945d2b16ade1de59e87c68b25cd23e17`.

Fetch that baseline (include its parent if using a shallow checkout), then apply source.patch with git apply --index. The result of git write-tree must equal the implementation tree above. Alternatively fetch the included source.bundle branch `fix/saria-song-receipt-crash-20261021` to restore the exact original implementation history. Complete changed-file copies and SHA-256 identities are in source/ and manifest.json. The preceding receipt-only source checkpoint is retained in this packet too.

Checks: python -B tests/custom_messages/run_decoder_tests.py; python -B tests/custom_messages/run_cutscene_actor_tests.py; python -B scripts/diagnostics/run_forest_actor_tests.py; python -B scripts/diagnostics/run_mm_item_receipt_tests.py --catalog-only. Supply nlohmann-json/spdlog headers for the native C++ fixtures. The included red log intentionally uses the original Saria grant and fails with decodedBuffer index 200. Green uses the finalized receipt.

No user crash log/dump or game assets are redistributed. No executable build was started. The game frame loop, rendering and input-driven receipt close remain runtime checks. All 23 talkable cutscene catalog entries are checked with controlled message/progression services in solo SoH and Combo; pose/placement preservation is tested rather than tracking-motion restoration.

Independent restoration verified both patch and bundle without Git object alternates.
